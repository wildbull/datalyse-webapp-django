from django.contrib import admin

# Register your models here.
from home.models import Questions
# Register your models here.
admin.site.register(Questions)
