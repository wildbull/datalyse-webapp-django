from django.contrib import admin
from .models import info
admin.site.register(info)

# Register your models here.
