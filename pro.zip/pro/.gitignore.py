*.pyc
*~
__pycache__
myvenv
db.sqlite3
/static
.DS_Store